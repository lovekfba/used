package com.bitstudy.app.dao;

public interface MyPageDao {
    int deleteCustomer(String cu_id);
}
